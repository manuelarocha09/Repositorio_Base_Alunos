numeros=[100,200,300,400]
numeros.pop(2)

print(numeros)