lista = ["a","b","c"]


lista[2]='x'


print(lista)