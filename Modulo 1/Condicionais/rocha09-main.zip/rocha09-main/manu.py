nomes = [ "Joaquim","Maria","ana"]
nomes.append("Gustavo")
nomes.append ("Pedro")

print(nomes[0])
print(nomes[1])
print(nomes[2])