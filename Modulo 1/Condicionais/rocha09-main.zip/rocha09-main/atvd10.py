numeros = [10,20,30,40,50]
numeros.append(60)

numeros.insert(1,15)

numeros.remove(30)

ultimo = numeros.pop()

print(numeros)
print(ultimo)