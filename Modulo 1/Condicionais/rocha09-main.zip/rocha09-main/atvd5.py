frutas= ["maça","banana","laranja"]
frutas.remove ("banana")

print(frutas)