letra = ["a","b","d"]
letra.insert(2,"c")

letra.remove("a")

print(letra)