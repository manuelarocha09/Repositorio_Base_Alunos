lista = ["python", "java","c++"]

del lista[1]

print(lista)